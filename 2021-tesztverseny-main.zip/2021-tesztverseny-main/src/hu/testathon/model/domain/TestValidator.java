package hu.testathon.model.domain;

public class TestValidator {

    private final String answers;

    public TestValidator(String answers) {
        this.answers = answers;
    }

    public String getAnswers() {
        return answers;
    }
}
