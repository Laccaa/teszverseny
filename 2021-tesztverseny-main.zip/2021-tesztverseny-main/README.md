# Tesztverseny
2017. tavasz

- [feladatlap](https://www.oktatas.hu/bin/content/dload/erettsegi/feladatok_2017tavasz_emelt/e_inf_17maj_fl.pdf)
- [források](https://www.oktatas.hu/bin/content/dload/erettsegi/feladatok_2017tavasz_emelt/e_inffor_17maj_fl.zip)